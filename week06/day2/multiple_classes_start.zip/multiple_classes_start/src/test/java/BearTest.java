import org.junit.Before;

public class BearTest {

    Bear bear;

    @Before
    public void before(){
        bear = new Bear("Baloo");
    }
}
