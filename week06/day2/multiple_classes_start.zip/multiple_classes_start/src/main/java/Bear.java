public class Bear {
    private String name;

    public Bear(String name){
        this.name = name;
    }
}